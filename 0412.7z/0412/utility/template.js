var tempOrder=
{
    "type": "template",
    "altText": "this is a buttons template",
    "template": {
      "type": "buttons",
      "actions": [
        {
          "type": "message",
          "label": "Query orderdetails",
          "text": "查詢訂單"
        },
        {
          "type": "message",
          "label": "$100 ~ $1000",
          "text": "$100 ~ $1000"
        },
        {
          "type": "message",
          "label": "$1000 ~ $3000",
          "text": "$1000 ~ $3000"
        },
        {
          "type": "message",
          "label": "More than $3000",
          "text": "More than $3000"
        }
      ],
      "title": "Question 4",
      "text": "How much do you use monthly?"
    }
  }